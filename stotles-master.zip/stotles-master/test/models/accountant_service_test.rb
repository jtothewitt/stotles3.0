require 'test_helper'

class AccountantServiceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
