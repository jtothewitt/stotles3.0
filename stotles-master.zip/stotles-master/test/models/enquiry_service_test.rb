require 'test_helper'

class EnquiryServiceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
