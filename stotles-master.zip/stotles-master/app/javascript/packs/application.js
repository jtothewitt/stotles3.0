import "bootstrap";
import { showForm } from './editEnquiry.js'
import { fillSummary } from './fillSummary.js'
import { toggleActive } from './toggleActive.js'
showForm();
fillSummary();
toggleActive();
